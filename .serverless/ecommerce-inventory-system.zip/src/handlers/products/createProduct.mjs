import { v4 as uuidv4 } from 'uuid';
import { dynamodb } from '../../utils/dynamodb.mjs';
import { successResponse, errorResponse } from '../../utils/apiResponse.mjs';

//const dynamodb = DynamoDBDocument.from(new DynamoDB({}));

export const handler = async (event) => {
    try{
        const { name, price, description } = JSON.parse(event.body);
        const productID = uuidv4();

        const product = {
            productID,
            name,
            price,
            description,
            createdAt: new Date().toISOString()
        };

        await dynamodb.put({
            TableName: process.env.PRODUCTS_TABLE,
            Item: product
        });

        return successResponse (product,201);
    }catch (error){
        console.log('Error in createProduts handler 1', error);
        return errorResponse(error);
    }
};

